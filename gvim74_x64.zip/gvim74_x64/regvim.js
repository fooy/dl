function LocalPath() {	
	return(decodeURI(WScript.ScriptFullName));
}
function GetDir(s) {	
	s.search(/(.*\\)/i);
	return(RegExp.$1.replace(/\//g,"\\"));
}
function regvim(){
	var vimpath=GetDir(LocalPath())+("gvim.exe");
	if(!vimpath){
        WScript.Echo("error path");
        return;
    }
	var WshShell = new ActiveXObject("WScript.Shell");
    //1.add to right mouse click menu &Edit with Vim
	var item1="HKCR\\\*\\shell\\edit with Vim\\";
	var param1=" --remote-tab-silent \"\%1\""

	WshShell.RegWrite(item1,"edit with &Vim","REG_SZ");
	WshShell.RegWrite(item1+"command\\","\""+vimpath+"\""+param1,"REG_SZ");

    //2.add to file->property->"open with" 
	var item2="HKCR\\Applications\\gvim.exe\\shell\\open\\command\\";
	var param2=" --remote-tab-silent \"\%1\""

	WshShell.RegWrite(item2,"\""+vimpath+"\""+param2,"REG_SZ");
    WScript.Echo("Register GVim app OK");
    //3.create short cut for IE:view source
	// create short cut for IE
    /*
	var lnkpath=GetDir(LocalPath())+"vimhtm.lnk"
	var oShellLink = WshShell.CreateShortcut(lnkpath);
	oShellLink.TargetPath="\""+vimpath+"\" -c \"set ft=html\" \"\%\*\"";
	oShellLink.WorkingDirectory = GetDir(vimpath);
	oShellLink.Description = "edit htm with vim";
	oShellLink.Save();
	//write to reg
	var item3="HKLM\\SOFTWARE\\Microsoft\\Internet Explorer\\View Source Editor\\Editor Name\\"
	WshShell.RegWrite(item3,lnkpath,"REG_SZ");
    WScript.Echo("������ݷ�ʽ�ɹ�");
    */
}
regvim()
